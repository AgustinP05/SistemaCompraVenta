/* =========================================================
   SISTEMA DE COMPRA Y VENTA - SCRIPT UNIFICADO
   Incluye: 
   1. Creación de Base de Datos y Tablas
   2. Inserción de Datos Base y de Prueba
   3. Creación de Stored Procedures
========================================================= */

/* ---------------------------------------------------------
   PARTE 1: CREAR BASE DE DATOS Y TABLAS
--------------------------------------------------------- */
CREATE DATABASE SistemaCompraVenta;
GO

USE SistemaCompraVenta;
GO

---- ROL ----
CREATE TABLE tRol (
    ID_Rol INT PRIMARY KEY IDENTITY(1,1),
    NombreRol VARCHAR(50) NOT NULL
); 
GO

---- PERMISO ----
CREATE TABLE tPermiso (
    ID_Permiso INT PRIMARY KEY IDENTITY(1,1),
    Nombre VARCHAR(100) NOT NULL
);
GO

---- USUARIO ----
CREATE TABLE tUsuario (
    ID INT PRIMARY KEY IDENTITY(1,1),
    DNI VARCHAR(20) NOT NULL UNIQUE,
    Nombre VARCHAR(50) NOT NULL,
    Apellido VARCHAR(100) NOT NULL,
    ID_Rol INT NOT NULL,
    Email VARCHAR(150) NOT NULL UNIQUE,
    FechaNacimiento DATE NOT NULL,
    FOREIGN KEY (ID_Rol) REFERENCES tRol(ID_Rol)
);
GO

---- ROL_PERMISO ----
CREATE TABLE tRolPermiso (
    ID_Rol INT NOT NULL,
    ID_Permiso INT NOT NULL,
    PRIMARY KEY (ID_Rol, ID_Permiso),
    FOREIGN KEY (ID_Rol) REFERENCES tRol(ID_Rol),
    FOREIGN KEY (ID_Permiso) REFERENCES tPermiso(ID_Permiso)
);
GO

---- ROL_COMPOSICION ----
CREATE TABLE tRolComposicion (
    ID_RolPadre INT NOT NULL,
    ID_RolHijo INT NOT NULL,
    PRIMARY KEY (ID_RolPadre, ID_RolHijo),
    FOREIGN KEY (ID_RolPadre) REFERENCES tRol(ID_Rol),
    FOREIGN KEY (ID_RolHijo) REFERENCES tRol(ID_Rol),
    CONSTRAINT CK_tRolComposicion_NoAutocontenido CHECK (ID_RolPadre <> ID_RolHijo)
);
GO

---- LOGLOGIN ----
CREATE TABLE tLogLogin (
    ID INT PRIMARY KEY IDENTITY(1,1),
    ID_Usuario INT NOT NULL,
    FechaHoraLogin DATETIME NOT NULL,
    FOREIGN KEY (ID_Usuario) REFERENCES tUsuario(ID)
);
GO

---- CLIENTE ----
CREATE TABLE tCliente (
    ID_Cliente INT PRIMARY KEY IDENTITY(1,1),
    DNI VARCHAR(20) NOT NULL UNIQUE,
    Nombre VARCHAR(100) NOT NULL,
    Apellido VARCHAR(100) NOT NULL,
    Telefono VARCHAR(100) NOT NULL,
    Email VARCHAR(100) NOT NULL,
    Direccion VARCHAR(100) NOT NULL
);
GO

---- PROVEEDOR ----
CREATE TABLE tProveedor (
    ID_Proveedor INT PRIMARY KEY IDENTITY(1,1),
    CUIT VARCHAR(20) NOT NULL UNIQUE,
    RazonSocial VARCHAR(100) NOT NULL,
    Telefono VARCHAR(100) NOT NULL,
    Email VARCHAR(100) NOT NULL,
    Direccion VARCHAR(100) NOT NULL
);
GO

---- CATEGORIA ----
CREATE TABLE tCategoria (
    ID_Categoria INT PRIMARY KEY IDENTITY(1,1),
    Nombre VARCHAR(50) NOT NULL UNIQUE
);
GO

---- PRODUCTO ----
CREATE TABLE tProducto (
    ID_Producto INT PRIMARY KEY IDENTITY(1,1),
    Nombre VARCHAR(100) NOT NULL,
    Marca VARCHAR(100) NOT NULL,
    ID_Categoria INT NOT NULL,
    PrecioVenta DECIMAL(10,2) NOT NULL,
    PrecioCosto DECIMAL(10,2) NOT NULL,
    FOREIGN KEY (ID_Categoria) REFERENCES tCategoria(ID_Categoria)
);
GO

---- PROVEEDOR_MARCA ----
CREATE TABLE tProveedorMarca (
    ID_Proveedor INT NOT NULL,
    Marca VARCHAR(100) NOT NULL,
    CONSTRAINT PK_tProveedorMarca PRIMARY KEY (Marca),
    FOREIGN KEY (ID_Proveedor) REFERENCES tProveedor(ID_Proveedor)
);
GO

---- COLOR ----
CREATE TABLE tColor (
    ID_Color INT PRIMARY KEY IDENTITY(1,1),
    Nombre VARCHAR(50) NOT NULL
);
GO

---- TALLE ----
CREATE TABLE tTalle (
    ID_Talle INT PRIMARY KEY IDENTITY(1,1),
    Valor VARCHAR(10) NOT NULL,
    ID_Categoria INT NOT NULL,
    FOREIGN KEY (ID_Categoria) REFERENCES tCategoria(ID_Categoria)
);
GO

---- PRODUCTO_VARIANTE ----
CREATE TABLE tProductoVariante (
    SKU INT PRIMARY KEY IDENTITY(1,1),
    ID_Producto INT NOT NULL,
    ID_Color INT NOT NULL,
    ID_Talle INT NOT NULL,
    Cantidad INT NOT NULL DEFAULT 0,
    CONSTRAINT CK_tProductoVariante_Cantidad CHECK (Cantidad >= 0),
    CONSTRAINT UQ_tProductoVariante UNIQUE (ID_Producto, ID_Color, ID_Talle),
    FOREIGN KEY (ID_Producto) REFERENCES tProducto(ID_Producto),
    FOREIGN KEY (ID_Color) REFERENCES tColor(ID_Color),
    FOREIGN KEY (ID_Talle) REFERENCES tTalle(ID_Talle)
);
GO

---- VENTA ----
CREATE TABLE tVenta (
    ID_Venta INT PRIMARY KEY IDENTITY(1,1),
    Fecha DATETIME NOT NULL,
    ID_Cliente INT NOT NULL,
    ID_Usuario INT NOT NULL,
    FOREIGN KEY (ID_Cliente) REFERENCES tCliente(ID_Cliente),
    FOREIGN KEY (ID_Usuario) REFERENCES tUsuario(ID)
);
GO

---- DETALLE_VENTA ----
CREATE TABLE tDetalleVenta (
    ID_DetalleVenta INT PRIMARY KEY IDENTITY(1,1),
    ID_Venta INT NOT NULL,
    SKU INT NOT NULL,
    Cantidad INT NOT NULL,
    PrecioUnitario DECIMAL(10,2) NOT NULL,
    FOREIGN KEY (ID_Venta) REFERENCES tVenta(ID_Venta),
    FOREIGN KEY (SKU) REFERENCES tProductoVariante(SKU)
);
GO

---- DESCUENTO_VENTA ----
CREATE TABLE tDescuentoVenta (
    ID_Descuento INT PRIMARY KEY IDENTITY(1,1),
    ID_Venta INT NOT NULL,
    Tipo VARCHAR(100) NOT NULL,
    Monto DECIMAL(10,2) NOT NULL,
    Fecha DATETIME NOT NULL DEFAULT GETDATE(),
    CONSTRAINT UQ_tDescuentoVenta_Venta UNIQUE (ID_Venta),
    FOREIGN KEY (ID_Venta) REFERENCES tVenta(ID_Venta)
);
GO

---- COMPRA ----
CREATE TABLE tCompra (
    ID_Compra INT PRIMARY KEY IDENTITY(1,1),
    Fecha DATETIME NOT NULL,
    ID_Usuario INT NOT NULL,
    ID_Proveedor INT NOT NULL,
    Estado VARCHAR(20) NOT NULL DEFAULT 'Pendiente',
    FechaRecepcion DATETIME NULL,
    ID_UsuarioRecepcion INT NULL,
    FOREIGN KEY (ID_Usuario) REFERENCES tUsuario(ID),
    FOREIGN KEY (ID_Proveedor) REFERENCES tProveedor(ID_Proveedor),
    FOREIGN KEY (ID_UsuarioRecepcion) REFERENCES tUsuario(ID)
);
GO

---- DETALLE_COMPRA ----
CREATE TABLE tDetalleCompra (
    ID_DetalleCompra INT PRIMARY KEY IDENTITY(1,1),
    ID_Compra INT NOT NULL,
    SKU INT NOT NULL,
    Cantidad INT NOT NULL,
    PrecioUnitario DECIMAL(10,2) NOT NULL,
    CantidadConfirmada INT NULL,
    FOREIGN KEY (ID_Compra) REFERENCES tCompra(ID_Compra),
    FOREIGN KEY (SKU) REFERENCES tProductoVariante(SKU)
);
GO

---- RECLAMO_COMPRA ----
CREATE TABLE tReclamoCompra (
    ID_Reclamo INT PRIMARY KEY IDENTITY(1,1),
    ID_Compra INT NOT NULL,
    SKU INT NOT NULL,
    CantidadPedida INT NOT NULL,
    CantidadRecibida INT NOT NULL,
    CantidadFaltante INT NOT NULL,
    FOREIGN KEY (ID_Compra) REFERENCES tCompra(ID_Compra),
    FOREIGN KEY (SKU) REFERENCES tProductoVariante(SKU)
);
GO

/* ---------------------------------------------------------
   PARTE 2: INSERCIÓN DE DATOS DE PRUEBA
--------------------------------------------------------- */
---- CATEGORIAS BASE ----
INSERT INTO tCategoria (Nombre) VALUES ('Vestimenta'), ('Calzado');
GO 

---- ROL ----
INSERT INTO tRol (NombreRol) VALUES
('Administrador'),   -- 1
('Vendedor'),        -- 2
('Gerente'),         -- 3
('Stock'),           -- 4
('Compras');         -- 5
GO

---- PERMISO ----
INSERT INTO tPermiso (Nombre) VALUES
('LogIn'),               -- 1
('GestionarUsuarios'),   -- 2
('RegistrarVentas'),     -- 3
('VerReportes'),         -- 4
('GestionarProductos'),  -- 5
('GestionarClientes'),   -- 6
('GestionarProveedores'),-- 7
('RegistrarCompras'),    -- 8
('ConfirmarCompras');    -- 9
GO

---- ROL_PERMISO ----
INSERT INTO tRolPermiso (ID_Rol, ID_Permiso) VALUES
(1, 2),                  -- Administrador: GestionarUsuarios
(2, 1), (2, 3), (2, 6),  -- Vendedor: LogIn, RegistrarVentas, GestionarClientes
(3, 1), (3, 4),          -- Gerente: LogIn, VerReportes
(4, 1), (4, 5), (4, 9),  -- Stock: LogIn, GestionarProductos, ConfirmarCompras
(5, 1), (5, 8), (5, 7);  -- Compras: LogIn, RegistrarCompras, GestionarProveedores
GO

---- ROL_COMPOSICION ----
INSERT INTO tRolComposicion (ID_RolPadre, ID_RolHijo) VALUES
(1, 2), (1, 3), (1, 4), (1, 5);
GO

---- USUARIO ----
INSERT INTO tUsuario (DNI, Nombre, Apellido, ID_Rol, Email, FechaNacimiento) VALUES
('11111111', 'Agustin',  'Perea',      1, 'aperea@sportupe.com.ar',    '1985-03-12'),  -- 1 
('22222222', 'Julieta',  'Lazaro',     2, 'jlazaro@sportupe.com.ar',   '1990-07-21'),  -- 2 
('27333444', 'Javier',   'Lopez',      2, 'jlopez@sportupe.com.ar',    '1988-05-02'),  -- 3 
('28455667', 'Lucia',    'Gomez',      2, 'lgomez@sportupe.com.ar',    '1991-02-14'),  -- 4 
('33333333', 'Sofia',    'Schenone',   3, 'sschenone@sportupe.com.ar', '1993-11-05'),  -- 5 
('44444444', 'Agostina', 'Villamayor', 4, 'avillamayor@sportupe.com.ar','1982-01-30'), -- 6 
('35888999', 'Camila',   'Diaz',       5, 'cdiaz@sportupe.com.ar',     '1996-09-18');  -- 7 
GO

---- LOGLOGIN ----
INSERT INTO tLogLogin (ID_Usuario, FechaHoraLogin) VALUES
(2, '2026-06-01 08:30:00'), (7, '2026-06-01 09:00:00'), (6, '2026-06-01 09:05:00'),
(3, '2026-06-02 08:45:00'), (5, '2026-06-02 10:15:00'), (7, '2026-06-02 11:00:00'),
(1, '2026-06-03 08:10:00'), (4, '2026-06-03 09:20:00'), (2, '2026-06-03 14:20:00'),
(7, '2026-06-04 08:35:00'), (3, '2026-06-04 10:05:00'), (6, '2026-06-04 12:40:00'),
(4, '2026-06-05 08:50:00'), (7, '2026-06-05 09:30:00'), (2, '2026-06-05 15:10:00'),
(3, '2026-06-08 08:25:00'), (5, '2026-06-08 09:45:00'), (6, '2026-06-08 11:15:00'),
(2, '2026-06-09 08:40:00'), (4, '2026-06-09 10:30:00'), (7, '2026-06-09 13:05:00'),
(3, '2026-06-10 08:20:00'), (1, '2026-06-10 09:10:00'), (6, '2026-06-10 16:00:00');
GO

---- CLIENTE ----
INSERT INTO tCliente (DNI, Nombre, Apellido, Telefono, Email, Direccion) VALUES
('34123456', 'Ana',       'Torres',   '1145678901', 'ana.torres@mail.com',      'Av. Rivadavia 1234, CABA'),       
('29876543', 'Bruno',     'Sosa',     '1156789012', 'bruno.sosa@mail.com',      'Calle Falsa 742, Lanus'),         
('31654987', 'Carla',     'Mendez',   '1167890123', 'carla.mendez@mail.com',    'Mitre 555, Avellaneda'),          
('27345678', 'Damian',    'Ruiz',     '1178901234', 'damian.ruiz@mail.com',     'San Martin 2020, Quilmes'),       
('36789123', 'Elena',     'Vega',     '1189012345', 'elena.vega@mail.com',      'Belgrano 88, Lomas de Zamora'),   
('30246813', 'Federico',  'Castro',   '1190123456', 'fede.castro@mail.com',     'Las Heras 1500, CABA'),           
('33112233', 'Gabriela',  'Ibarra',   '1101234567', 'gabriela.ibarra@mail.com', 'Corrientes 3300, CABA'),          
('28567890', 'Hernan',    'Paz',      '1112345678', 'hernan.paz@mail.com',      'Cabildo 2100, CABA'),             
('35678901', 'Irina',     'Luna',     '1123456789', 'irina.luna@mail.com',      'Maipu 470, Vicente Lopez'),       
('29012345', 'Joaquin',   'Rios',     '1134567890', 'joaquin.rios@mail.com',    'Alsina 990, Banfield'),           
('32345609', 'Karen',     'Ferreyra', '1145012390', 'karen.ferreyra@mail.com',  'Yrigoyen 130, Moron'),            
('31890123', 'Leandro',   'Cabrera',  '1156012390', 'leandro.cabrera@mail.com', 'Sarmiento 760, San Isidro'),      
('33456712', 'Mariana',   'Ortiz',    '1167012390', 'mariana.ortiz@mail.com',   'Pueyrredon 2400, CABA'),          
('27901234', 'Nahuel',    'Gimenez',  '1178012390', 'nahuel.gimenez@mail.com',  'Brown 350, Adrogue'),             
('36012378', 'Oriana',    'Silva',    '1189012390', 'oriana.silva@mail.com',    'Lavalle 1820, CABA'),             
('30123489', 'Pablo',     'Dominguez','1190012390', 'pablo.dominguez@mail.com', 'Triunvirato 4100, CABA'),         
('34567812', 'Romina',    'Aguero',   '1101012390', 'romina.aguero@mail.com',   'Entre Rios 540, Lanus'),          
('28678923', 'Sebastian', 'Molina',   '1112012390', 'sebastian.molina@mail.com','Rivadavia 8800, CABA'),           
('35789034', 'Tamara',    'Vera',     '1123012390', 'tamara.vera@mail.com',     'Mitre 1200, Temperley'),          
('29890145', 'Ulises',    'Campos',   '1134012390', 'ulises.campos@mail.com',   'Roca 670, Berazategui'),          
('32901256', 'Victoria',  'Suarez',   '1145112390', 'victoria.suarez@mail.com', 'Belgrano 2300, CABA'),            
('31012367', 'Walter',    'Pereyra',  '1156112390', 'walter.pereyra@mail.com',  'San Juan 1450, CABA');            
GO

---- PROVEEDOR ----
INSERT INTO tProveedor (CUIT, RazonSocial, Telefono, Email, Direccion) VALUES
('30712345678', 'Nike Argentina SRL',            '1143210001', 'mayorista@nikearg.com',      'Au. Panamericana km 30'),     
('33765432109', 'Adidas Mayorista SA',           '1143210002', 'b2b@adidasmay.com',          'Ruta 8 km 25, Malvinas'),     
('30555666778', 'Puma Sports SRL',               '1143210003', 'ventas@pumasports.com',      'Av. del Trabajo 4500, CABA'), 
('30698765432', 'Distribuidora Deportiva SA',    '1143210004', 'ventas@distdeportiva.com',   'Parque Industrial Pilar'),    
('27888999001', 'Importadora Atletica SA',       '1143210005', 'compras@impatletica.com',    'Dock Sud, Avellaneda'),       
('30444555667', 'Mayorista Indumentaria SRL',    '1143210006', 'info@mayindumentaria.com',   'Once 1200, CABA'),            
('30222333445', 'Calzados del Sur SA',           '1143210007', 'ventas@calzadosdelsur.com',  'Ruta 2 km 50, La Plata'),     
('33111222339', 'SportTotal SRL',                '1143210008', 'mayorista@sporttotal.com',   'Av. Mitre 3400, Avellaneda'), 
('30999888771', 'UrbanWear SA',                  '1143210009', 'b2b@urbanwear.com',          'Gorriti 5200, CABA'),         
('27666555441', 'Deportes Olimpo SRL',           '1143210010', 'ventas@deportesolimpo.com',  'San Martin 900, Moron'),      
('30333444556', 'TextilPro SA',                  '1143210011', 'compras@textilpro.com',      'Parque Industrial Burzaco'),  
('33444555661', 'Mundo Running SRL',             '1143210012', 'info@mundorunning.com',      'Cabildo 3300, CABA'),         
('30777888993', 'Atleta Mayorista SA',           '1143210013', 'b2b@atletamay.com',          'Au. Riccheri km 12'),         
('27555444332', 'Indumentaria Norte SRL',        '1143210014', 'ventas@indunorte.com',       'Belgrano 4500, San Miguel'),  
('30888999003', 'ProSport Distribuciones SA',    '1143210015', 'mayorista@prosport.com',     'Av. Hipolito 2100, Lanus'),   
('33222333447', 'La Casa del Deporte SRL',       '1143210016', 'ventas@casadeldeporte.com',  'Rivadavia 5600, CABA'),       
('30111222338', 'Sporthing SA',                  '1143210017', 'b2b@sporthing.com',          'Maipu 1300, Vicente Lopez'),  
('27333222115', 'MegaDeportes SRL',              '1143210018', 'compras@megadeportes.com',   'Ruta 3 km 30, La Matanza'),   
('30666777884', 'Distribuidora Andina SA',       '1143210019', 'ventas@distandina.com',      'Parque Industrial Pilar 2'),  
('33555666772', 'Equipo Total SRL',              '1143210020', 'info@equipototal.com',       'Yrigoyen 2800, Lomas');       
GO

---- PROVEEDOR_MARCA ----
INSERT INTO tProveedorMarca (ID_Proveedor, Marca) VALUES
(1,  'Nike'),
(2,  'Adidas'),
(3,  'Puma'),
(4,  'Topper'), (4, 'Fila'), (4, 'Reebok'),            
(5,  'Under Armour'), (5, 'New Balance'),              
(6,  'Lacoste'), (6, 'Kappa'), (6, 'Umbro'),          
(7,  'Diadora'),
(8,  'Asics'), (8, 'Mizuno'),                          
(9,  'Vans'), (9, 'Converse'),                         
(10, 'Joma'),
(11, 'Penalty'), (11, 'Lotto'),                        
(12, 'Saucony'),
(13, 'Wilson'), (13, 'Babolat'),                       
(14, 'Montagne'),
(15, 'Le Coq Sportif'),
(16, 'Champion'), (16, 'Russell'),                     
(17, 'Hummel'),
(18, 'Macron'),
(19, 'Dunlop'), (19, 'Head'),                          
(20, 'Sergio Tacchini');
GO

---- PRODUCTO ----
INSERT INTO tProducto (Nombre, Marca, ID_Categoria, PrecioVenta, PrecioCosto) VALUES
('Zapatilla Running Air',     'Nike',         2, 120000.00, 70000.00),  
('Remera Dry-Fit',            'Nike',         1,  32000.00, 15000.00),  
('Zapatilla Ultraboost',      'Adidas',       2, 150000.00, 90000.00),  
('Short Tiro',                'Adidas',       1,  28000.00, 13000.00),  
('Zapatilla Urbana RS-X',     'Puma',         2, 110000.00, 65000.00),  
('Campera Rompeviento',       'Puma',         1,  85000.00, 48000.00),  
('Zapatilla Topper Pro',      'Topper',       2,  70000.00, 40000.00),  
('Botin Fila Premium',        'Fila',         2,  95000.00, 55000.00),  
('Buzo Reebok Classic',       'Reebok',       1,  60000.00, 32000.00),  
('Remera Under Armour Tech',  'Under Armour', 1,  45000.00, 22000.00),  
('Zapatilla New Balance 574', 'New Balance',  2, 130000.00, 78000.00),  
('Chomba Lacoste Classic',    'Lacoste',      1,  75000.00, 40000.00),  
('Camiseta Kappa Retro',      'Kappa',        1,  38000.00, 18000.00),  
('Camiseta Umbro Arquero',    'Umbro',        1,  42000.00, 20000.00),  
('Botin Diadora Brasil',      'Diadora',      2,  88000.00, 50000.00),  
('Zapatilla Asics Gel',       'Asics',        2, 140000.00, 85000.00),  
('Zapatilla Mizuno Wave',     'Mizuno',       2, 135000.00, 82000.00),  
('Zapatilla Vans Old Skool',  'Vans',         2,  95000.00, 55000.00),  
('Zapatilla Converse Chuck',  'Converse',     2,  85000.00, 48000.00),  
('Medias Joma Pack x3',       'Joma',         1,  12000.00,  5000.00),  
('Camiseta Penalty Pro',      'Penalty',      1,  36000.00, 17000.00),  
('Campera Lotto Sport',       'Lotto',        1,  78000.00, 44000.00),  
('Zapatilla Saucony Ride',    'Saucony',      2, 125000.00, 74000.00),  
('Buzo Champion Logo',        'Champion',     1,  65000.00, 35000.00);  
GO

---- COLOR ----
INSERT INTO tColor (Nombre) VALUES
('Negro'),        
('Blanco'),       
('Rojo'),         
('Azul'),         
('Gris'),         
('Verde'),        
('Amarillo'),     
('Naranja'),      
('Violeta'),      
('Rosa'),         
('Celeste'),      
('Bordo'),        
('Marron'),       
('Beige'),        
('Turquesa'),     
('Fucsia'),       
('Verde Militar'),
('Dorado'),       
('Plateado'),     
('Coral');        
GO

---- TALLE ----
INSERT INTO tTalle (Valor, ID_Categoria) VALUES
('35', 2),  
('36', 2),  
('37', 2),  
('38', 2),  
('39', 2),  
('40', 2),  
('41', 2),  
('42', 2),  
('43', 2),  
('44', 2),  
('45', 2),  
('46', 2),  
('XXS', 1), 
('XS',  1), 
('S',   1), 
('M',   1), 
('L',   1), 
('XL',  1), 
('XXL', 1), 
('XXXL',1); 
GO

---- PRODUCTO_VARIANTE ----
INSERT INTO tProductoVariante (ID_Producto, ID_Color, ID_Talle, Cantidad) VALUES
( 1,  1,  6, 12),  
( 1,  2,  7,  8),  
( 1,  3,  8,  5),  
( 2,  2, 16, 25),  
( 2,  1, 17, 18),  
( 3,  1,  8, 10),  
( 3,  4,  9,  6),  
( 4,  3, 15, 20),  
( 5,  5, 10,  9),  
( 6,  4, 17,  7),  
( 7,  1,  7, 15),  
( 8,  2,  9,  4),  
( 9,  5, 16, 11),  
(10,  1, 18, 13),  
(11,  5,  8, 14),  
(12,  6, 16, 16),  
(13,  3, 15,  9),  
(14,  7, 17,  8),  
(15,  1,  6,  6),  
(16,  4,  9, 10),  
(17,  8, 10,  5),  
(18,  1,  7, 20),  
(19,  2,  8, 17),  
(20,  1, 16, 30),  
(21,  4, 17, 12),  
(22,  3, 18,  7),  
(23,  5, 11,  6),  
(24,  1, 19,  9),  
( 1,  1,  9,  4),  
( 3,  2,  8,  9),  
( 5,  1,  9,  8),  
( 2,  3, 15, 10);  
GO

---- VENTA ----
INSERT INTO tVenta (Fecha, ID_Cliente, ID_Usuario) VALUES
('2026-05-02 10:15:00',  1, 2),  
('2026-05-03 16:40:00',  2, 3),  
('2026-05-05 11:20:00',  3, 4),  
('2026-05-06 18:05:00',  4, 2),  
('2026-05-08 09:50:00',  5, 3),  
('2026-05-09 13:30:00',  6, 4),  
('2026-05-11 12:10:00',  7, 2),  
('2026-05-12 17:25:00',  8, 3),  
('2026-05-14 10:40:00',  9, 4),  
('2026-05-15 15:55:00', 10, 2),  
('2026-05-17 11:05:00', 11, 3),  
('2026-05-18 18:30:00', 12, 4),  
('2026-05-20 09:35:00', 13, 2),  
('2026-05-21 14:15:00', 14, 3),  
('2026-05-23 16:50:00', 15, 4),  
('2026-05-24 10:25:00', 16, 2),  
('2026-05-26 12:45:00', 17, 3),  
('2026-05-27 17:10:00', 18, 4),  
('2026-05-29 09:20:00', 19, 2),  
('2026-05-30 15:35:00', 20, 3),  
('2026-06-01 11:50:00', 21, 4),  
('2026-06-02 16:05:00', 22, 2);  
GO

---- DETALLE_VENTA ----
INSERT INTO tDetalleVenta (ID_Venta, SKU, Cantidad, PrecioUnitario) VALUES
( 1,  1, 1, 120000.00),
( 2,  4, 2,  32000.00), ( 2,  6, 1, 150000.00),
( 3,  9, 1, 110000.00), ( 3, 10, 1,  85000.00), ( 3, 13, 2,  60000.00),
( 4, 15, 1, 130000.00),
( 5,  2, 1, 120000.00), ( 5,  8, 3,  95000.00),
( 6, 11, 1,  70000.00), ( 6, 16, 1, 140000.00), ( 6, 24, 2,  12000.00),
( 7, 17, 2, 135000.00),
( 8, 19, 1,  88000.00), ( 8, 22, 1,  95000.00),
( 9, 23, 1,  85000.00),
(10,  3, 1, 120000.00), (10,  5, 1, 110000.00), (10, 14, 1,  45000.00),
(11, 25, 2,  36000.00),
(12, 26, 1,  78000.00), (12, 28, 1,  65000.00),
(13,  7, 1, 150000.00),
(14, 12, 1,  75000.00), (14, 18, 2,  95000.00), (14, 20, 1, 140000.00),
(15, 21, 1, 135000.00),
(16, 27, 1, 125000.00), (16, 24, 1,  12000.00),
(17, 29, 1, 120000.00),
(18, 30, 1, 150000.00), (18, 31, 1, 110000.00),
(19, 32, 2, 120000.00), (19,  4, 1,  32000.00), (19, 10, 1,  85000.00),
(20, 13, 1,  60000.00),
(21, 16, 1, 140000.00), (21, 11, 1,  70000.00),
(22,  2, 2, 120000.00), (22,  5, 1, 110000.00), (22,  9, 1, 110000.00);
GO

---- DESCUENTO_VENTA ----
INSERT INTO tDescuentoVenta (ID_Venta, Tipo, Monto) VALUES
( 1, 'Monto fijo $6000',   6000.00),   
( 2, 'Porcentaje 5%',     10700.00),   
( 3, 'Por volumen',       31500.00),   
( 4, 'Monto fijo $2500',   2500.00),   
( 5, 'Por volumen',       60750.00),   
( 6, 'Por volumen',       23400.00),   
( 7, 'Porcentaje 10%',    27000.00),   
( 8, 'Monto fijo $9000',   9000.00),   
( 9, 'Monto fijo $8000',   8000.00),   
(10, 'Porcentaje 10%',    27500.00),   
(11, 'Monto fijo $3600',   3600.00),   
(12, 'Monto fijo $14000', 14000.00),   
(13, 'Porcentaje 5%',      7500.00),   
(14, 'Porcentaje 5%',     20250.00),   
(16, 'Monto fijo $12000', 12000.00),   
(18, 'Por volumen',       26000.00),   
(19, 'Por volumen',       35700.00),   
(20, 'Monto fijo $2000',   2000.00),   
(21, 'Porcentaje 5%',     10500.00),   
(22, 'Por volumen',       69000.00);   
GO

---- COMPRA ----
INSERT INTO tCompra (Fecha, ID_Usuario, ID_Proveedor, Estado, FechaRecepcion, ID_UsuarioRecepcion) VALUES
('2026-04-01 09:00:00', 7,  1, 'Confirmada', '2026-04-04 10:00:00', 6),  
('2026-04-02 10:30:00', 7,  2, 'Confirmada', '2026-04-05 09:30:00', 6),  
('2026-04-03 14:00:00', 7,  3, 'Reclamo',    '2026-04-06 11:00:00', 6),  
('2026-04-04 11:45:00', 7,  4, 'Confirmada', '2026-04-07 16:00:00', 6),  
('2026-04-05 16:20:00', 7,  5, 'Pendiente',  NULL, NULL),                
('2026-04-06 09:15:00', 7,  6, 'Confirmada', '2026-04-09 10:30:00', 6),  
('2026-04-07 10:50:00', 7,  7, 'Confirmada', '2026-04-10 09:00:00', 6),  
('2026-04-08 15:30:00', 7,  8, 'Reclamo',    '2026-04-11 11:30:00', 6),  
('2026-04-09 09:40:00', 7,  9, 'Confirmada', '2026-04-12 10:15:00', 6),  
('2026-04-10 11:10:00', 7, 10, 'Confirmada', '2026-04-13 16:20:00', 6),  
('2026-04-11 16:05:00', 7, 11, 'Pendiente',  NULL, NULL),                
('2026-04-12 09:25:00', 7, 12, 'Confirmada', '2026-04-15 10:40:00', 6),  
('2026-04-13 10:35:00', 7, 16, 'Confirmada', '2026-04-16 09:50:00', 6),  
('2026-04-14 14:20:00', 7,  1, 'Confirmada', '2026-04-17 11:10:00', 6),  
('2026-04-15 09:55:00', 7,  2, 'Reclamo',    '2026-04-18 10:05:00', 6),  
('2026-04-16 11:30:00', 7,  3, 'Confirmada', '2026-04-19 16:35:00', 6),  
('2026-04-17 16:45:00', 7,  4, 'Pendiente',  NULL, NULL),                
('2026-04-18 09:05:00', 7,  6, 'Confirmada', '2026-04-21 10:20:00', 6),  
('2026-04-19 10:15:00', 7,  8, 'Confirmada', '2026-04-22 11:45:00', 6),  
('2026-04-20 15:50:00', 7,  5, 'Confirmada', '2026-04-23 09:25:00', 6),  
('2026-04-21 09:35:00', 7,  9, 'Confirmada', '2026-04-24 10:55:00', 6),  
('2026-04-22 11:20:00', 7, 11, 'Reclamo',    '2026-04-25 16:10:00', 6);  
GO

---- DETALLE_COMPRA ----
INSERT INTO tDetalleCompra (ID_Compra, SKU, Cantidad, PrecioUnitario, CantidadConfirmada) VALUES
-- 1 Confirmada
( 1,  1, 10, 70000.00, 10), ( 1,  4, 20, 15000.00, 20),
-- 2 Confirmada
( 2,  6, 10, 90000.00, 10), ( 2,  8,  6, 13000.00,  6),
-- 3 Reclamo 
( 3,  9, 12, 65000.00,  5), ( 3, 10,  8, 48000.00,  8),
-- 4 Confirmada
( 4, 11, 15, 40000.00, 15), ( 4, 12,  8, 55000.00,  8), ( 4, 13, 10, 32000.00, 10),
-- 5 Pendiente
( 5, 14, 10, 22000.00, NULL), ( 5, 15, 12, 78000.00, NULL),
-- 6 Confirmada
( 6, 16, 12, 40000.00, 12), ( 6, 17,  9, 18000.00,  9), ( 6, 18,  8, 20000.00,  8),
-- 7 Confirmada
( 7, 19,  6, 50000.00,  6),
-- 8 Reclamo 
( 8, 20, 10, 85000.00, 10), ( 8, 21,  8, 82000.00,  3),
-- 9 Confirmada
( 9, 22, 20, 55000.00, 20), ( 9, 23, 17, 48000.00, 17),
-- 10 Confirmada
(10, 24, 30,  5000.00, 30),
-- 11 Pendiente
(11, 25, 12, 17000.00, NULL), (11, 26,  7, 44000.00, NULL),
-- 12 Confirmada
(12, 27,  6, 74000.00,  6),
-- 13 Confirmada
(13, 28,  9, 35000.00,  9),
-- 14 Confirmada
(14,  2,  8, 70000.00,  8), (14, 29,  4, 70000.00,  4), (14, 32, 10, 15000.00, 10),
-- 15 Reclamo 
(15,  7,  6, 90000.00,  4), (15, 30, 10, 90000.00, 10),
-- 16 Confirmada
(16, 31,  8, 65000.00,  8),
-- 17 Pendiente
(17, 11,  5, 40000.00, NULL),
-- 18 Confirmada
(18, 16,  6, 40000.00,  6), (18, 17,  5, 18000.00,  5),
-- 19 Confirmada
(19, 20,  8, 85000.00,  8), (19, 21, 10, 82000.00, 10),
-- 20 Confirmada
(20, 14,  8, 22000.00,  8), (20, 15,  6, 78000.00,  6),
-- 21 Confirmada
(21, 22, 12, 55000.00, 12),
-- 22 Reclamo 
(22, 25, 12, 17000.00,  8), (22, 26, 10, 44000.00,  7);
GO

---- RECLAMO_COMPRA ----
INSERT INTO tReclamoCompra (ID_Compra, SKU, CantidadPedida, CantidadRecibida, CantidadFaltante) VALUES
( 3,  9, 12,  5,  7),
( 8, 21,  8,  3,  5),
(15,  7,  6,  4,  2),
(22, 25, 12,  8,  4),
(22, 26, 10,  7,  3);
GO

/* ---------------------------------------------------------
   PARTE 3: STORED PROCEDURES
--------------------------------------------------------- */
-- LOGIN ---------------------------------------------------------------------
IF OBJECT_ID('SP_LoginUsuario', 'P') IS NOT NULL DROP PROCEDURE SP_LoginUsuario;
GO
CREATE PROCEDURE SP_LoginUsuario(@Usuario VARCHAR(150))
AS BEGIN
    SELECT u.ID, u.Nombre, u.Apellido, u.ID_Rol, r.NombreRol AS Rol, u.DNI, u.FechaNacimiento
    FROM tUsuario u
    JOIN tRol r ON r.ID_Rol = u.ID_Rol
    WHERE LEFT(u.Email, CHARINDEX('@', u.Email) - 1) = @Usuario;
END;
GO
---
IF OBJECT_ID('SP_RegistrarLogin', 'P') IS NOT NULL DROP PROCEDURE SP_RegistrarLogin;
GO
CREATE PROCEDURE SP_RegistrarLogin(@ID_Usuario INT, @FechaHoraLogin DATETIME)
AS BEGIN
    INSERT INTO tLogLogin(ID_Usuario, FechaHoraLogin)
    VALUES(@ID_Usuario, @FechaHoraLogin);
END;
GO


-- USUARIO -------------------------------------------------------------------
IF OBJECT_ID('SP_ObtenerUsuarios', 'P') IS NOT NULL DROP PROCEDURE SP_ObtenerUsuarios;
GO
CREATE PROCEDURE SP_ObtenerUsuarios
    @Filtro VARCHAR(20) = ''
AS
BEGIN
    SELECT u.ID, u.DNI, u.Nombre, u.Apellido, u.Email, r.NombreRol AS Rol,
           u.ID_Rol, u.FechaNacimiento
    FROM tUsuario u
    JOIN tRol r ON r.ID_Rol = u.ID_Rol
    WHERE @Filtro = '' OR u.DNI LIKE '%' + @Filtro + '%'
    ORDER BY u.Nombre;
END;
GO
---
IF OBJECT_ID('SP_InsertarUsuario', 'P') IS NOT NULL DROP PROCEDURE SP_InsertarUsuario;
GO
CREATE PROCEDURE SP_InsertarUsuario(
    @DNI VARCHAR(20),
    @Nombre VARCHAR(50),
    @Apellido VARCHAR(100),
    @ID_Rol INT,
    @Email VARCHAR(150),
    @FechaNacimiento DATE
)
AS BEGIN
    INSERT INTO tUsuario (DNI, Nombre, Apellido, ID_Rol, Email, FechaNacimiento)
    VALUES (@DNI, @Nombre, @Apellido, @ID_Rol, @Email, @FechaNacimiento);
    SELECT SCOPE_IDENTITY() AS ID_Usuario;
END;
GO
---
IF OBJECT_ID('SP_EliminarUsuario', 'P') IS NOT NULL DROP PROCEDURE SP_EliminarUsuario;
GO
CREATE PROCEDURE SP_EliminarUsuario
    @DNI VARCHAR(20)
AS
BEGIN
    DELETE FROM tUsuario WHERE DNI = @DNI;
END;
GO
---
IF OBJECT_ID('SP_ModificarUsuario', 'P') IS NOT NULL DROP PROCEDURE SP_ModificarUsuario;
GO
CREATE PROCEDURE SP_ModificarUsuario
    @DNI VARCHAR(20), @Nombre VARCHAR(50), @Apellido VARCHAR(100),
    @ID_Rol INT, @Email VARCHAR(150),
    @FechaNacimiento DATE
AS
BEGIN
    UPDATE tUsuario
    SET Nombre = @Nombre, Apellido = @Apellido,
        ID_Rol = @ID_Rol, Email = @Email, FechaNacimiento = @FechaNacimiento
    WHERE DNI = @DNI;
END;
GO
---
IF OBJECT_ID('SP_ExisteEmail', 'P') IS NOT NULL DROP PROCEDURE SP_ExisteEmail;
GO
CREATE PROCEDURE SP_ExisteEmail
    @Email VARCHAR(150), @DniExcluir VARCHAR(20) = NULL
AS
BEGIN
    SELECT TOP 1 ID FROM tUsuario
    WHERE Email = @Email AND (@DniExcluir IS NULL OR DNI <> @DniExcluir);
END;
GO


-- CLIENTES ------------------------------------------------------------------
IF OBJECT_ID('SP_ListarClientes', 'P') IS NOT NULL DROP PROCEDURE SP_ListarClientes;
GO
CREATE PROCEDURE SP_ListarClientes
AS
BEGIN
    SELECT ID_Cliente, DNI, Nombre, Apellido, Telefono, Email, Direccion
    FROM tCliente;
END;
GO
---
IF OBJECT_ID('SP_ObtenerClientes', 'P') IS NOT NULL DROP PROCEDURE SP_ObtenerClientes;
GO
CREATE PROCEDURE SP_ObtenerClientes
    @Filtro VARCHAR(100)
AS
BEGIN
    SELECT ID_Cliente, DNI, Nombre, Apellido, Direccion, Telefono, Email
    FROM tCliente
    WHERE DNI LIKE '%' + @Filtro + '%'
       OR Nombre LIKE '%' + @Filtro + '%'
       OR Apellido LIKE '%' + @Filtro + '%'
    ORDER BY Nombre;
END;
GO
---
IF OBJECT_ID('SP_InsertarCliente', 'P') IS NOT NULL DROP PROCEDURE SP_InsertarCliente;
GO
CREATE PROCEDURE SP_InsertarCliente(
    @DNI VARCHAR(20), @Nombre VARCHAR(100), @Apellido VARCHAR(100),
    @Telefono VARCHAR(100), @Email VARCHAR(100), @Direccion VARCHAR(100)
)
AS BEGIN
    INSERT INTO tCliente (DNI, Nombre, Apellido, Telefono, Email, Direccion)
    VALUES (@DNI, @Nombre, @Apellido, @Telefono, @Email, @Direccion);
    SELECT SCOPE_IDENTITY() AS ID_Cliente;
END;
GO
---
IF OBJECT_ID('SP_EliminarCliente', 'P') IS NOT NULL DROP PROCEDURE SP_EliminarCliente;
GO
CREATE PROCEDURE SP_EliminarCliente
    @ID_Cliente INT
AS
BEGIN
    DELETE FROM tCliente WHERE ID_Cliente = @ID_Cliente;
END;
GO
---
IF OBJECT_ID('SP_ExisteCliente', 'P') IS NOT NULL DROP PROCEDURE SP_ExisteCliente;
GO
CREATE PROCEDURE SP_ExisteCliente
    @DNI VARCHAR(20)
AS
BEGIN
    SELECT ID_Cliente FROM tCliente WHERE DNI = @DNI;
END;
GO
---
IF OBJECT_ID('SP_ModificarCliente', 'P') IS NOT NULL DROP PROCEDURE SP_ModificarCliente;
GO
CREATE PROCEDURE SP_ModificarCliente
    @ID_Cliente INT, @DNI VARCHAR(20), @Nombre VARCHAR(100), @Apellido VARCHAR(100),
    @Direccion VARCHAR(100), @Telefono VARCHAR(100), @Email VARCHAR(100)
AS
BEGIN
    UPDATE tCliente
    SET DNI = @DNI, Nombre = @Nombre, Apellido = @Apellido,
        Direccion = @Direccion, Telefono = @Telefono, Email = @Email
    WHERE ID_Cliente = @ID_Cliente;
END;
GO


-- VENTAS --------------------------------------------------------------------
IF OBJECT_ID('SP_ProximoNumeroVenta', 'P') IS NOT NULL DROP PROCEDURE SP_ProximoNumeroVenta;
GO
CREATE PROCEDURE SP_ProximoNumeroVenta
AS
BEGIN
    SELECT ISNULL(MAX(ID_Venta), 0) + 1 AS ProximoNumero FROM tVenta;
END;
GO
---
IF OBJECT_ID('SP_RegistrarVenta', 'P') IS NOT NULL DROP PROCEDURE SP_RegistrarVenta;
GO
CREATE PROCEDURE SP_RegistrarVenta(@Fecha DATETIME, @ID_Cliente INT, @ID_Usuario INT)
AS BEGIN
    INSERT INTO tVenta (Fecha, ID_Cliente, ID_Usuario)
    VALUES (@Fecha, @ID_Cliente, @ID_Usuario);
    SELECT SCOPE_IDENTITY() AS ID_Venta;
END;
GO
---
IF OBJECT_ID('SP_ObtenerVentaPorId', 'P') IS NOT NULL DROP PROCEDURE SP_ObtenerVentaPorId;
GO
CREATE PROCEDURE SP_ObtenerVentaPorId(@ID_Venta INT)
AS BEGIN
    SELECT v.ID_Venta, v.Fecha,
           c.ID_Cliente, c.DNI AS ClienteDNI, c.Nombre AS ClienteNombre, c.Apellido AS ClienteApellido,
           u.ID AS UsuarioID, u.Nombre AS UsuarioNombre, u.Apellido AS UsuarioApellido
    FROM tVenta v
    JOIN tCliente c ON c.ID_Cliente = v.ID_Cliente
    JOIN tUsuario u ON u.ID = v.ID_Usuario
    WHERE v.ID_Venta = @ID_Venta;
END;
GO
---
IF OBJECT_ID('SP_ObtenerDetalleVentaPorId', 'P') IS NOT NULL DROP PROCEDURE SP_ObtenerDetalleVentaPorId;
GO
CREATE PROCEDURE SP_ObtenerDetalleVentaPorId(@ID_Venta INT)
AS BEGIN
    SELECT dv.SKU, p.Nombre, p.Marca, t.Valor AS Talle, col.Nombre AS Color,
           dv.Cantidad, dv.PrecioUnitario
    FROM tDetalleVenta dv
    JOIN tProductoVariante pv ON pv.SKU = dv.SKU
    JOIN tProducto p ON p.ID_Producto = pv.ID_Producto
    JOIN tColor col ON col.ID_Color = pv.ID_Color
    JOIN tTalle t ON t.ID_Talle = pv.ID_Talle
    WHERE dv.ID_Venta = @ID_Venta;
END;
GO
---
IF OBJECT_ID('SP_ObtenerDescuentoVenta', 'P') IS NOT NULL DROP PROCEDURE SP_ObtenerDescuentoVenta;
GO
CREATE PROCEDURE SP_ObtenerDescuentoVenta(@ID_Venta INT)
AS BEGIN
    SELECT Tipo, Monto FROM tDescuentoVenta WHERE ID_Venta = @ID_Venta;
END;
GO


-- DESCUENTO VENTA (auditoría) -----------------------------------------------
IF OBJECT_ID('SP_InsertarDescuentoVenta', 'P') IS NOT NULL DROP PROCEDURE SP_InsertarDescuentoVenta;
GO
CREATE PROCEDURE SP_InsertarDescuentoVenta(
    @ID_Venta INT, @Tipo VARCHAR(100), @Monto DECIMAL(10,2)
)
AS BEGIN
    INSERT INTO tDescuentoVenta (ID_Venta, Tipo, Monto)
    VALUES (@ID_Venta, @Tipo, @Monto);
END;
GO


-- DETALLE VENTAS ------------------------------------------------------------
IF OBJECT_ID('SP_InsertarDetalleVenta', 'P') IS NOT NULL DROP PROCEDURE SP_InsertarDetalleVenta;
GO
CREATE PROCEDURE SP_InsertarDetalleVenta(
    @ID_Venta INT, @SKU INT, @Cantidad INT, @PrecioUnitario DECIMAL(10,2)
)
AS BEGIN
    INSERT INTO tDetalleVenta (ID_Venta, SKU, Cantidad, PrecioUnitario)
    VALUES (@ID_Venta, @SKU, @Cantidad, @PrecioUnitario);
END;
GO


-- STOCK ---------------------------------------------------------------------
IF OBJECT_ID('SP_ActualizarStock', 'P') IS NOT NULL DROP PROCEDURE SP_ActualizarStock; 
IF OBJECT_ID('SP_RestarStock', 'P') IS NOT NULL DROP PROCEDURE SP_RestarStock;
GO
CREATE PROCEDURE SP_RestarStock(@SKU INT, @Cantidad INT)
AS BEGIN
    UPDATE tProductoVariante
    SET Cantidad = Cantidad - @Cantidad
    WHERE SKU = @SKU AND Cantidad >= @Cantidad;

    IF @@ROWCOUNT = 0
        THROW 50001, 'Stock insuficiente: la venta dejaría stock negativo.', 1;
END;
GO
---
IF OBJECT_ID('SP_BuscarStock', 'P') IS NOT NULL DROP PROCEDURE SP_BuscarStock;
GO
CREATE PROCEDURE SP_BuscarStock
    @SKU INT
AS BEGIN
    SELECT Cantidad FROM tProductoVariante WHERE SKU = @SKU;
END;
GO


-- PRODUCTOS -----------------------------------------------------------------
IF OBJECT_ID('SP_ListarProductos', 'P') IS NOT NULL DROP PROCEDURE SP_ListarProductos;
GO
CREATE PROCEDURE SP_ListarProductos AS BEGIN
    SELECT p.ID_Producto, p.Nombre, p.Marca, p.ID_Categoria, c.Nombre AS Categoria,
           p.PrecioVenta, p.PrecioCosto
    FROM tProducto p
    JOIN tCategoria c ON c.ID_Categoria = p.ID_Categoria;
END;
GO
---
IF OBJECT_ID('SP_InsertarProducto', 'P') IS NOT NULL DROP PROCEDURE SP_InsertarProducto;
GO
CREATE PROCEDURE SP_InsertarProducto(
    @Nombre VARCHAR(100), @Marca VARCHAR(100), @ID_Categoria INT,
    @PrecioVenta DECIMAL(10,2), @PrecioCosto DECIMAL(10,2)
)
AS BEGIN
    INSERT INTO tProducto (Nombre, Marca, ID_Categoria, PrecioVenta, PrecioCosto)
    VALUES (@Nombre, @Marca, @ID_Categoria, @PrecioVenta, @PrecioCosto);
    SELECT SCOPE_IDENTITY() AS ID_Producto;
END;
GO
---
IF OBJECT_ID('SP_ObtenerProductos', 'P') IS NOT NULL DROP PROCEDURE SP_ObtenerProductos;
GO
CREATE PROCEDURE SP_ObtenerProductos
    @Filtro VARCHAR(100)
AS BEGIN
    SELECT p.ID_Producto, p.Nombre, p.Marca, p.ID_Categoria, c.Nombre AS Categoria,
           p.PrecioVenta, p.PrecioCosto
    FROM tProducto p
    JOIN tCategoria c ON c.ID_Categoria = p.ID_Categoria
    WHERE p.Nombre LIKE '%' + @Filtro + '%'
       OR p.Marca  LIKE '%' + @Filtro + '%'
       OR CAST(p.ID_Producto AS VARCHAR(20)) LIKE '%' + @Filtro + '%'
    ORDER BY p.Nombre;
END;
GO
---
IF OBJECT_ID('SP_ObtenerProductoPorId', 'P') IS NOT NULL DROP PROCEDURE SP_ObtenerProductoPorId;
GO
CREATE PROCEDURE SP_ObtenerProductoPorId
    @ID_Producto INT
AS BEGIN
    SELECT p.ID_Producto, p.Nombre, p.Marca, p.ID_Categoria, c.Nombre AS Categoria,
           p.PrecioVenta, p.PrecioCosto
    FROM tProducto p
    JOIN tCategoria c ON c.ID_Categoria = p.ID_Categoria
    WHERE p.ID_Producto = @ID_Producto;
END;
GO
---
IF OBJECT_ID('SP_ModificarProducto', 'P') IS NOT NULL DROP PROCEDURE SP_ModificarProducto;
GO
CREATE PROCEDURE SP_ModificarProducto
    @ID_Producto INT, @Nombre VARCHAR(100), @Marca VARCHAR(100),
    @ID_Categoria INT, @PrecioVenta DECIMAL(10,2), @PrecioCosto DECIMAL(10,2)
AS BEGIN
    UPDATE tProducto
    SET Nombre = @Nombre, Marca = @Marca, ID_Categoria = @ID_Categoria,
        PrecioVenta = @PrecioVenta, PrecioCosto = @PrecioCosto
    WHERE ID_Producto = @ID_Producto;
END;
GO
---
IF OBJECT_ID('SP_EliminarProducto', 'P') IS NOT NULL DROP PROCEDURE SP_EliminarProducto;
GO
CREATE PROCEDURE SP_EliminarProducto
    @ID_Producto INT
AS BEGIN
    DELETE FROM tProducto WHERE ID_Producto = @ID_Producto;
END;
GO


-- PRODUCTO_VARIANTE ---------------------------------------------------------
IF OBJECT_ID('SP_ListarVariantes', 'P') IS NOT NULL DROP PROCEDURE SP_ListarVariantes;
GO
CREATE PROCEDURE SP_ListarVariantes AS BEGIN
    SELECT pv.SKU, p.Nombre, p.Marca, p.PrecioVenta, p.PrecioCosto,
           c.Nombre AS Color, t.Valor AS Talle, pv.Cantidad
    FROM tProductoVariante pv
    JOIN tProducto p ON p.ID_Producto = pv.ID_Producto
    JOIN tColor    c ON c.ID_Color    = pv.ID_Color
    JOIN tTalle    t ON t.ID_Talle    = pv.ID_Talle;
END;
GO
---
IF OBJECT_ID('SP_ObtenerVariantes', 'P') IS NOT NULL DROP PROCEDURE SP_ObtenerVariantes;
GO
CREATE PROCEDURE SP_ObtenerVariantes
    @Filtro VARCHAR(100)
AS BEGIN
    SELECT pv.SKU, p.Nombre, p.Marca, t.Valor AS Talle, c.Nombre AS Color,
           pv.Cantidad, p.PrecioVenta
    FROM tProductoVariante pv
    JOIN tProducto p ON p.ID_Producto = pv.ID_Producto
    JOIN tColor    c ON c.ID_Color    = pv.ID_Color
    JOIN tTalle    t ON t.ID_Talle    = pv.ID_Talle
    WHERE CAST(pv.SKU AS VARCHAR(20)) LIKE '%' + @Filtro + '%'
       OR p.Nombre LIKE '%' + @Filtro + '%'
    ORDER BY p.Nombre;
END;
GO
---
IF OBJECT_ID('SP_ListarVariantesPorProducto', 'P') IS NOT NULL DROP PROCEDURE SP_ListarVariantesPorProducto;
GO
CREATE PROCEDURE SP_ListarVariantesPorProducto
    @ID_Producto INT
AS BEGIN
    SELECT pv.SKU, c.Nombre AS Color, t.Valor AS Talle, pv.Cantidad
    FROM tProductoVariante pv
    JOIN tColor c ON c.ID_Color = pv.ID_Color
    JOIN tTalle t ON t.ID_Talle = pv.ID_Talle
    WHERE pv.ID_Producto = @ID_Producto
    ORDER BY t.Valor, c.Nombre;
END;
GO
---
IF OBJECT_ID('SP_ExisteVariante', 'P') IS NOT NULL DROP PROCEDURE SP_ExisteVariante;
GO
CREATE PROCEDURE SP_ExisteVariante
    @ID_Producto INT, @ID_Color INT, @ID_Talle INT
AS BEGIN
    SELECT SKU FROM tProductoVariante
    WHERE ID_Producto = @ID_Producto AND ID_Color = @ID_Color AND ID_Talle = @ID_Talle;
END;
GO
---
IF OBJECT_ID('SP_InsertarVariante', 'P') IS NOT NULL DROP PROCEDURE SP_InsertarVariante;
GO
CREATE PROCEDURE SP_InsertarVariante
    @ID_Producto INT, @ID_Color INT, @ID_Talle INT
AS BEGIN
    INSERT INTO tProductoVariante (ID_Producto, ID_Color, ID_Talle)
    VALUES (@ID_Producto, @ID_Color, @ID_Talle);
    SELECT SCOPE_IDENTITY() AS SKU;
END;
GO
---
IF OBJECT_ID('SP_ListarColores', 'P') IS NOT NULL DROP PROCEDURE SP_ListarColores;
GO
CREATE PROCEDURE SP_ListarColores AS BEGIN
    SELECT ID_Color, Nombre FROM tColor ORDER BY Nombre;
END;
GO
---
IF OBJECT_ID('SP_ListarCategorias', 'P') IS NOT NULL DROP PROCEDURE SP_ListarCategorias;
GO
CREATE PROCEDURE SP_ListarCategorias AS BEGIN
    SELECT ID_Categoria, Nombre FROM tCategoria ORDER BY Nombre;
END;
GO
---
IF OBJECT_ID('SP_ListarTallesPorCategoria', 'P') IS NOT NULL DROP PROCEDURE SP_ListarTallesPorCategoria;
GO
CREATE PROCEDURE SP_ListarTallesPorCategoria
    @ID_Categoria INT
AS BEGIN
    SELECT ID_Talle, Valor FROM tTalle WHERE ID_Categoria = @ID_Categoria ORDER BY Valor;
END;
GO


-- VISTA DE GERENTE ----------------------------------------------------------
IF OBJECT_ID('sp_GenerarReporteVentas', 'P') IS NOT NULL DROP PROCEDURE sp_GenerarReporteVentas;
GO
CREATE PROCEDURE sp_GenerarReporteVentas(
    @Desde DATETIME,
    @Hasta DATETIME,
    @IdVendedor INT = NULL,
    @IdProducto INT = NULL,
    @IdCliente INT = NULL,
    @IdCategoria INT = NULL
)
AS BEGIN
    SELECT 
        v.ID_Venta, 
        v.Fecha, 
        c.Nombre + ' ' + c.Apellido AS NombreCliente,
        u.Nombre + ' ' + u.Apellido AS NombreVendedor,
        p.Nombre AS DescripcionProducto,
        dv.Cantidad,
        (dv.Cantidad * dv.PrecioUnitario) AS Subtotal,
        (dv.Cantidad * p.PrecioCosto) AS Costo,
        ISNULL(dvto.Monto, 0) AS Descuento,
        ISNULL(dvto.Tipo, '') AS TipoDescuento
    FROM tVenta v
    JOIN tCliente c ON v.ID_Cliente = c.ID_Cliente
    JOIN tUsuario u ON v.ID_Usuario = u.ID
    JOIN tDetalleVenta dv ON v.ID_Venta = dv.ID_Venta
    JOIN tProductoVariante pv ON dv.SKU = pv.SKU
    JOIN tProducto p ON pv.ID_Producto = p.ID_Producto
    LEFT JOIN tDescuentoVenta dvto ON dvto.ID_Venta = v.ID_Venta
    WHERE
        v.Fecha >= @Desde AND v.Fecha <= @Hasta
        AND (@IdVendedor IS NULL OR v.ID_Usuario = @IdVendedor)
        AND (@IdProducto IS NULL OR p.ID_Producto = @IdProducto)
        AND (@IdCliente IS NULL OR v.ID_Cliente = @IdCliente)
        AND (@IdCategoria IS NULL OR p.ID_Categoria = @IdCategoria)
    ORDER BY v.Fecha DESC;
END;
GO
---
IF OBJECT_ID('SP_ListarVendedores', 'P') IS NOT NULL DROP PROCEDURE SP_ListarVendedores;
GO
CREATE PROCEDURE SP_ListarVendedores
AS BEGIN
    SELECT u.ID, (u.Nombre + ' ' + u.Apellido) AS Nombre, r.NombreRol AS Rol
    FROM tUsuario u
    JOIN tRol r ON r.ID_Rol = u.ID_Rol
    WHERE r.NombreRol = 'Vendedor'
       OR EXISTS (SELECT 1 FROM tVenta v WHERE v.ID_Usuario = u.ID)
    ORDER BY Nombre;
END;
GO


-- ROL -----------------------------------------------------------------------
IF OBJECT_ID('SP_ListarRoles', 'P') IS NOT NULL DROP PROCEDURE SP_ListarRoles;
GO
CREATE PROCEDURE SP_ListarRoles
AS
BEGIN
    SELECT ID_Rol, NombreRol FROM tRol ORDER BY NombreRol;
END;
GO
---
IF OBJECT_ID('SP_PermisosPorRol', 'P') IS NOT NULL DROP PROCEDURE SP_PermisosPorRol;
GO
CREATE PROCEDURE SP_PermisosPorRol(@ID_Rol INT)
AS
BEGIN
    SELECT p.ID_Permiso, p.Nombre
    FROM tRolPermiso rp
    JOIN tPermiso p ON p.ID_Permiso = rp.ID_Permiso
    WHERE rp.ID_Rol = @ID_Rol;
END;
GO
---
IF OBJECT_ID('SP_ListarPermisos', 'P') IS NOT NULL DROP PROCEDURE SP_ListarPermisos;
GO
CREATE PROCEDURE SP_ListarPermisos
AS
BEGIN
    SELECT ID_Permiso, Nombre FROM tPermiso ORDER BY Nombre;
END;
GO
---
IF OBJECT_ID('SP_AsignarPermisoRol', 'P') IS NOT NULL DROP PROCEDURE SP_AsignarPermisoRol;
GO
CREATE PROCEDURE SP_AsignarPermisoRol(@ID_Rol INT, @ID_Permiso INT)
AS
BEGIN
    IF NOT EXISTS (SELECT 1 FROM tRolPermiso WHERE ID_Rol = @ID_Rol AND ID_Permiso = @ID_Permiso)
        INSERT INTO tRolPermiso (ID_Rol, ID_Permiso) VALUES (@ID_Rol, @ID_Permiso);
END;
GO
---
IF OBJECT_ID('SP_QuitarPermisosRol', 'P') IS NOT NULL DROP PROCEDURE SP_QuitarPermisosRol;
GO
CREATE PROCEDURE SP_QuitarPermisosRol(@ID_Rol INT)
AS
BEGIN
    DELETE FROM tRolPermiso WHERE ID_Rol = @ID_Rol;
END;
GO
---
IF OBJECT_ID('SP_ListarFamilias',    'P') IS NOT NULL DROP PROCEDURE SP_ListarFamilias;
IF OBJECT_ID('SP_PermisosDeFamilia', 'P') IS NOT NULL DROP PROCEDURE SP_PermisosDeFamilia;
IF OBJECT_ID('SP_FamiliasPorRol',    'P') IS NOT NULL DROP PROCEDURE SP_FamiliasPorRol;
IF OBJECT_ID('SP_AsignarFamiliaRol', 'P') IS NOT NULL DROP PROCEDURE SP_AsignarFamiliaRol;
IF OBJECT_ID('SP_QuitarFamiliasRol', 'P') IS NOT NULL DROP PROCEDURE SP_QuitarFamiliasRol;
GO
---
IF OBJECT_ID('SP_SubRolesDeRol', 'P') IS NOT NULL DROP PROCEDURE SP_SubRolesDeRol;
GO
CREATE PROCEDURE SP_SubRolesDeRol(@ID_Rol INT)
AS
BEGIN
    SELECT r.ID_Rol, r.NombreRol
    FROM tRolComposicion rc
    JOIN tRol r ON r.ID_Rol = rc.ID_RolHijo
    WHERE rc.ID_RolPadre = @ID_Rol;
END;
GO
---
IF OBJECT_ID('SP_AsignarSubRol', 'P') IS NOT NULL DROP PROCEDURE SP_AsignarSubRol;
GO
CREATE PROCEDURE SP_AsignarSubRol(@ID_RolPadre INT, @ID_RolHijo INT)
AS
BEGIN
    IF @ID_RolPadre <> @ID_RolHijo
       AND NOT EXISTS (SELECT 1 FROM tRolComposicion
                       WHERE ID_RolPadre = @ID_RolPadre AND ID_RolHijo = @ID_RolHijo)
        INSERT INTO tRolComposicion (ID_RolPadre, ID_RolHijo)
        VALUES (@ID_RolPadre, @ID_RolHijo);
END;
GO
---
IF OBJECT_ID('SP_QuitarSubRolesRol', 'P') IS NOT NULL DROP PROCEDURE SP_QuitarSubRolesRol;
GO
CREATE PROCEDURE SP_QuitarSubRolesRol(@ID_Rol INT)
AS
BEGIN
    DELETE FROM tRolComposicion WHERE ID_RolPadre = @ID_Rol;
END;
GO


-- PROVEEDOR -----------------------------------------------------------------
IF OBJECT_ID('SP_InsertarProveedor', 'P') IS NOT NULL DROP PROCEDURE SP_InsertarProveedor;
GO
CREATE PROCEDURE SP_InsertarProveedor (
    @CUIT VARCHAR(20), @RazonSocial VARCHAR(100), @Telefono VARCHAR(100),
    @Email VARCHAR(100), @Direccion VARCHAR(100)
)
AS BEGIN
    INSERT INTO tProveedor (CUIT, RazonSocial, Telefono, Email, Direccion)
    VALUES (@CUIT, @RazonSocial, @Telefono, @Email, @Direccion);
    SELECT SCOPE_IDENTITY() AS ID_Proveedor;
END;
GO
---
IF OBJECT_ID('SP_ExisteProveedor', 'P') IS NOT NULL DROP PROCEDURE SP_ExisteProveedor;
GO
CREATE PROCEDURE SP_ExisteProveedor (@CUIT VARCHAR(20))
AS BEGIN
    SELECT ID_Proveedor FROM tProveedor WHERE CUIT = @CUIT;
END;
GO
---
IF OBJECT_ID('SP_ObtenerProveedores', 'P') IS NOT NULL DROP PROCEDURE SP_ObtenerProveedores;
GO
CREATE PROCEDURE SP_ObtenerProveedores (@Filtro VARCHAR(100))
AS BEGIN
    SELECT ID_Proveedor, CUIT, RazonSocial, Telefono, Email, Direccion
    FROM tProveedor
    WHERE CUIT        LIKE '%' + @Filtro + '%'
       OR RazonSocial LIKE '%' + @Filtro + '%'
    ORDER BY RazonSocial;
END;
GO
---
IF OBJECT_ID('SP_ModificarProveedor', 'P') IS NOT NULL DROP PROCEDURE SP_ModificarProveedor;
GO
CREATE PROCEDURE SP_ModificarProveedor (
    @CUIT VARCHAR(20), @RazonSocial VARCHAR(100), @Telefono VARCHAR(100),
    @Email VARCHAR(100), @Direccion VARCHAR(100)
)
AS BEGIN
    UPDATE tProveedor
    SET RazonSocial = @RazonSocial, Telefono = @Telefono,
        Email = @Email, Direccion = @Direccion
    WHERE CUIT = @CUIT;
END;
GO
---
IF OBJECT_ID('SP_EliminarProveedor', 'P') IS NOT NULL DROP PROCEDURE SP_EliminarProveedor;
GO
CREATE PROCEDURE SP_EliminarProveedor (@CUIT VARCHAR(20))
AS BEGIN
    DELETE FROM tProveedor WHERE CUIT = @CUIT;
END;
GO
---
IF OBJECT_ID('SP_ListarProveedores', 'P') IS NOT NULL DROP PROCEDURE SP_ListarProveedores;
GO
CREATE PROCEDURE SP_ListarProveedores
AS BEGIN
    SELECT ID_Proveedor, CUIT, RazonSocial, Telefono, Email, Direccion
    FROM tProveedor
    ORDER BY RazonSocial;
END;
GO


-- COMPRAS -------------------------------------------------------------------
IF OBJECT_ID('SP_SumarStock', 'P') IS NOT NULL DROP PROCEDURE SP_SumarStock;
GO
CREATE PROCEDURE SP_SumarStock(@SKU INT, @Cantidad INT)
AS BEGIN
    UPDATE tProductoVariante
    SET Cantidad = Cantidad + @Cantidad
    WHERE SKU = @SKU;
END;
GO
---
IF OBJECT_ID('SP_ProximoNumeroCompra', 'P') IS NOT NULL DROP PROCEDURE SP_ProximoNumeroCompra;
GO
CREATE PROCEDURE SP_ProximoNumeroCompra
AS BEGIN
    SELECT ISNULL(MAX(ID_Compra), 0) + 1 AS ProximoNumero FROM tCompra;
END;
GO
---
IF OBJECT_ID('SP_RegistrarCompra', 'P') IS NOT NULL DROP PROCEDURE SP_RegistrarCompra;
GO
CREATE PROCEDURE SP_RegistrarCompra(@Fecha DATETIME, @ID_Proveedor INT, @ID_Usuario INT)
AS BEGIN
    INSERT INTO tCompra (Fecha, ID_Proveedor, ID_Usuario, Estado)
    VALUES (@Fecha, @ID_Proveedor, @ID_Usuario, 'Pendiente');
    SELECT SCOPE_IDENTITY() AS ID_Compra;
END;
GO
---
IF OBJECT_ID('SP_InsertarDetalleCompra', 'P') IS NOT NULL DROP PROCEDURE SP_InsertarDetalleCompra;
GO
CREATE PROCEDURE SP_InsertarDetalleCompra(
    @ID_Compra INT, @SKU INT, @Cantidad INT, @PrecioUnitario DECIMAL(10,2)
)
AS BEGIN
    INSERT INTO tDetalleCompra (ID_Compra, SKU, Cantidad, PrecioUnitario)
    VALUES (@ID_Compra, @SKU, @Cantidad, @PrecioUnitario);
END;
GO
---
IF OBJECT_ID('SP_ListarComprasPendientes', 'P') IS NOT NULL DROP PROCEDURE SP_ListarComprasPendientes;
GO
CREATE PROCEDURE SP_ListarComprasPendientes
AS BEGIN
    SELECT c.ID_Compra, c.Fecha, pr.RazonSocial AS Proveedor,
           u.Nombre + ' ' + u.Apellido AS Usuario,
           (SELECT SUM(dc.Cantidad * dc.PrecioUnitario)
              FROM tDetalleCompra dc WHERE dc.ID_Compra = c.ID_Compra) AS Total
    FROM tCompra c
    JOIN tProveedor pr ON pr.ID_Proveedor = c.ID_Proveedor
    JOIN tUsuario   u  ON u.ID            = c.ID_Usuario
    WHERE c.Estado = 'Pendiente'
    ORDER BY c.Fecha;
END;
GO
---
IF OBJECT_ID('SP_ObtenerCompraPorId', 'P') IS NOT NULL DROP PROCEDURE SP_ObtenerCompraPorId;
GO
CREATE PROCEDURE SP_ObtenerCompraPorId(@ID_Compra INT)
AS BEGIN
    SELECT c.ID_Compra, c.Fecha, c.Estado,
           pr.ID_Proveedor, pr.CUIT AS ProveedorCUIT, pr.RazonSocial AS ProveedorRazonSocial,
           u.ID AS UsuarioID, u.Nombre AS UsuarioNombre, u.Apellido AS UsuarioApellido
    FROM tCompra c
    JOIN tProveedor pr ON pr.ID_Proveedor = c.ID_Proveedor
    JOIN tUsuario   u  ON u.ID            = c.ID_Usuario
    WHERE c.ID_Compra = @ID_Compra;
END;
GO
---
IF OBJECT_ID('SP_ObtenerDetalleCompraPorId', 'P') IS NOT NULL DROP PROCEDURE SP_ObtenerDetalleCompraPorId;
GO
CREATE PROCEDURE SP_ObtenerDetalleCompraPorId(@ID_Compra INT)
AS BEGIN
    SELECT dc.SKU, p.Nombre, p.Marca, t.Valor AS Talle, col.Nombre AS Color,
           dc.Cantidad, dc.PrecioUnitario, dc.CantidadConfirmada
    FROM tDetalleCompra dc
    JOIN tProductoVariante pv ON pv.SKU = dc.SKU
    JOIN tProducto p   ON p.ID_Producto = pv.ID_Producto
    JOIN tColor    col ON col.ID_Color  = pv.ID_Color
    JOIN tTalle    t   ON t.ID_Talle    = pv.ID_Talle
    WHERE dc.ID_Compra = @ID_Compra;
END;
GO
---
IF OBJECT_ID('SP_ConfirmarDetalleCompra', 'P') IS NOT NULL DROP PROCEDURE SP_ConfirmarDetalleCompra;
GO
CREATE PROCEDURE SP_ConfirmarDetalleCompra(@ID_Compra INT, @SKU INT, @CantidadConfirmada INT)
AS BEGIN
    UPDATE tDetalleCompra
    SET CantidadConfirmada = @CantidadConfirmada
    WHERE ID_Compra = @ID_Compra AND SKU = @SKU;
END;
GO
---
IF OBJECT_ID('SP_ActualizarEstadoCompra', 'P') IS NOT NULL DROP PROCEDURE SP_ActualizarEstadoCompra;
GO
IF OBJECT_ID('SP_CerrarRecepcionCompra', 'P') IS NOT NULL DROP PROCEDURE SP_CerrarRecepcionCompra;
GO
CREATE PROCEDURE SP_CerrarRecepcionCompra(
    @ID_Compra INT, @Estado VARCHAR(20),
    @FechaRecepcion DATETIME, @ID_UsuarioRecepcion INT
)
AS BEGIN
    UPDATE tCompra
    SET Estado = @Estado,
        FechaRecepcion = @FechaRecepcion,
        ID_UsuarioRecepcion = @ID_UsuarioRecepcion
    WHERE ID_Compra = @ID_Compra;
END;
GO
---
IF OBJECT_ID('SP_InsertarReclamoCompra', 'P') IS NOT NULL DROP PROCEDURE SP_InsertarReclamoCompra;
GO
CREATE PROCEDURE SP_InsertarReclamoCompra(
    @ID_Compra INT, @SKU INT,
    @CantidadPedida INT, @CantidadRecibida INT, @CantidadFaltante INT
)
AS BEGIN
    INSERT INTO tReclamoCompra (ID_Compra, SKU, CantidadPedida, CantidadRecibida, CantidadFaltante)
    VALUES (@ID_Compra, @SKU, @CantidadPedida, @CantidadRecibida, @CantidadFaltante);
END;
GO
---
IF OBJECT_ID('SP_ListarReclamos', 'P') IS NOT NULL DROP PROCEDURE SP_ListarReclamos;
GO
CREATE PROCEDURE SP_ListarReclamos
AS BEGIN
    SELECT
        r.ID_Compra                          AS NroCompra,
        co.Fecha                             AS FechaCompra,
        pr.RazonSocial                       AS Proveedor,
        p.Nombre                             AS Producto,
        cl.Nombre                            AS Color,
        t.Valor                              AS Talle,
        r.CantidadPedida                     AS Pedido,
        r.CantidadRecibida                   AS Recibido,
        r.CantidadFaltante                   AS Faltante,
        co.FechaRecepcion                    AS FechaReclamo
    FROM tReclamoCompra r
    JOIN tCompra co            ON co.ID_Compra   = r.ID_Compra
    JOIN tProveedor pr         ON pr.ID_Proveedor = co.ID_Proveedor
    JOIN tProductoVariante pv  ON pv.SKU         = r.SKU
    JOIN tProducto p           ON p.ID_Producto  = pv.ID_Producto
    JOIN tColor cl             ON cl.ID_Color    = pv.ID_Color
    JOIN tTalle t              ON t.ID_Talle     = pv.ID_Talle
    ORDER BY co.FechaRecepcion DESC, r.ID_Compra;
END;
GO


-- PROVEEDOR_MARCA -----------------------------------------------------------
IF OBJECT_ID('SP_MarcasDeProveedor', 'P') IS NOT NULL DROP PROCEDURE SP_MarcasDeProveedor;
GO
CREATE PROCEDURE SP_MarcasDeProveedor(@ID_Proveedor INT)
AS BEGIN
    SELECT Marca FROM tProveedorMarca WHERE ID_Proveedor = @ID_Proveedor ORDER BY Marca;
END;
GO
---
IF OBJECT_ID('SP_ListarMarcas', 'P') IS NOT NULL DROP PROCEDURE SP_ListarMarcas;
GO
CREATE PROCEDURE SP_ListarMarcas AS BEGIN
    SELECT DISTINCT Marca FROM tProveedorMarca ORDER BY Marca;
END;
GO
---
IF OBJECT_ID('SP_AsociarMarcaProveedor', 'P') IS NOT NULL DROP PROCEDURE SP_AsociarMarcaProveedor;
GO
CREATE PROCEDURE SP_AsociarMarcaProveedor
    @ID_Proveedor INT, @Marca VARCHAR(100)
AS BEGIN
    INSERT INTO tProveedorMarca (ID_Proveedor, Marca) VALUES (@ID_Proveedor, @Marca);
END;
GO
---
IF OBJECT_ID('SP_ObtenerProveedorPorSku', 'P') IS NOT NULL DROP PROCEDURE SP_ObtenerProveedorPorSku;
GO
CREATE PROCEDURE SP_ObtenerProveedorPorSku
    @SKU INT
AS BEGIN
    SELECT pr.ID_Proveedor, pr.CUIT, pr.RazonSocial, pr.Telefono, pr.Email, pr.Direccion
    FROM tProductoVariante pv
    JOIN tProducto p        ON p.ID_Producto   = pv.ID_Producto
    JOIN tProveedorMarca pm ON pm.Marca         = p.Marca
    JOIN tProveedor pr      ON pr.ID_Proveedor  = pm.ID_Proveedor
    WHERE pv.SKU = @SKU;
END;
GO
---
IF OBJECT_ID('SP_ListarVariantesPorProveedor', 'P') IS NOT NULL DROP PROCEDURE SP_ListarVariantesPorProveedor;
GO
CREATE PROCEDURE SP_ListarVariantesPorProveedor(@ID_Proveedor INT) AS BEGIN
    SELECT pv.SKU, p.Nombre, p.Marca, p.PrecioVenta, p.PrecioCosto,
           c.Nombre AS Color, t.Valor AS Talle, pv.Cantidad
    FROM tProductoVariante pv
    JOIN tProducto p ON p.ID_Producto = pv.ID_Producto
    JOIN tColor    c ON c.ID_Color    = pv.ID_Color
    JOIN tTalle    t ON t.ID_Talle    = pv.ID_Talle
    JOIN tProveedorMarca pm ON pm.Marca = p.Marca AND pm.ID_Proveedor = @ID_Proveedor;
END;
GO
---
IF OBJECT_ID('SP_ObtenerVariantesPorProveedor', 'P') IS NOT NULL DROP PROCEDURE SP_ObtenerVariantesPorProveedor;
GO
CREATE PROCEDURE SP_ObtenerVariantesPorProveedor(@Filtro VARCHAR(100), @ID_Proveedor INT)
AS BEGIN
    SELECT pv.SKU, p.Nombre, p.Marca, t.Valor AS Talle, c.Nombre AS Color,
           pv.Cantidad, p.PrecioVenta
    FROM tProductoVariante pv
    JOIN tProducto p ON p.ID_Producto = pv.ID_Producto
    JOIN tColor    c ON c.ID_Color    = pv.ID_Color
    JOIN tTalle    t ON t.ID_Talle    = pv.ID_Talle
    JOIN tProveedorMarca pm ON pm.Marca = p.Marca AND pm.ID_Proveedor = @ID_Proveedor
    WHERE CAST(pv.SKU AS VARCHAR(20)) LIKE '%' + @Filtro + '%'
       OR p.Nombre LIKE '%' + @Filtro + '%'
    ORDER BY p.Nombre;
END;
GO